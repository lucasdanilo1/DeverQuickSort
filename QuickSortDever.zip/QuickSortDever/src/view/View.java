package view;

import java.util.Scanner;

 public class View {
	private Scanner scanner;

    public View() {
        scanner = new Scanner(System.in);
    }

    public int[] getInputNumbers() {
        int[] numbers = new int[10];
        System.out.println("Insira 10 numeros:");
        for (int i = 0; i < 10; i++) {
            numbers[i] = scanner.nextInt();
        }
        return numbers;
    }

    public void displayNumbers(int[] numbers) {
        System.out.println("Numeros: ");
        for (int number : numbers) {
            System.out.print(number + " ");
        }
        System.out.println();
    }
}
