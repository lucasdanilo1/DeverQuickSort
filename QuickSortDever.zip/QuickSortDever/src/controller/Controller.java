package controller;

import model.Model;
import view.View;

public class Controller {

	private Model model;
    private View view;

    public Controller(Model model, View view) {
        this.model = model;
        this.view = view;
    }

    public void sortUsingInsertionSort() {
        model.insertionSort();
        view.displayNumbers(model.getNumbers());
    }

    public void sortUsingQuickSort() {
        model.quickSort();
        view.displayNumbers(model.getNumbers());
    }

    public void execute() {
        int[] numbers = view.getInputNumbers();
        model = new Model(numbers);

        System.out.println("Before sorting:");
        view.displayNumbers(numbers);

        System.out.println("Sorting using Insertion Sort:");
        sortUsingInsertionSort();

        model = new Model(numbers);
        System.out.println("Sorting using QuickSort:");
        sortUsingQuickSort();
    }

    public static void main(String[] args) {
        View view = new View();
        Model model = new Model(new int[10]);
        Controller controller = new Controller(model, view);
        controller.execute();
    }

}
